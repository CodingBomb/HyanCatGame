
#ifndef TEXASM_H
#define TEXASM_H


#include <stdio.h>
#include <windows.h>
#include "..\..\include\hge.h"

extern HGE *hge;

void SysLog(const char *format, ...);


#endif
