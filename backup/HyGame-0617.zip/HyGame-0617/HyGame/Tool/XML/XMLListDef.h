#ifndef XMLLISTDEF_
#define XMLLISTDEF_

#include "XMLParseDef.h"
#include <string>

struct XMLFileObject
{
    std::string Id;
    std::string Type;
    std::string Path;
};

#endif